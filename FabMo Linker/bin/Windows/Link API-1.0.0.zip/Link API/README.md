# local-api

## Requirement

[Node.js](http://nodejs.org/)

## Usage

This API is to be used in localhost.
It provide easy ways to detect tools on the networks.
It works on port 8080.  

launch the API : 
```bash
node server.js  
```
  
Documentation of the API [here](http://docs.shopbotlocalapi.apiary.io/)

## Developing

develloped by [jlucidar](github.com/jlucidar)

### Tools

Created with [Nodeclipse](http://www.nodeclipse.org)  
Using [Restify](http://mcavage.me/node-restify/)

